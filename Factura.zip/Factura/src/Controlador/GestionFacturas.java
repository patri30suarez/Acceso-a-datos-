/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Empleado;
import Modelo.Producto;
import Modelo.Cliente;
import Modelo.Detalle;
import Modelo.Factura;
import javax.swing.JComboBox;
import java.sql.*;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author patt
 * */
public class GestionFacturas {

    // <editor-fold defaultstate="collapsed" desc="CargarDatos code">                          
    public static void cargarComboProductos(JComboBox<Producto> cmbProductos) throws SQLException {
        Producto p;
        cmbProductos.removeAllItems();
        String consulta = "select * from productos";
        ResultSet rs;

        try ( Statement sentencia = Pool.getCurrentConexion().createStatement()) {
            rs = sentencia.executeQuery(consulta);
            cmbProductos.addItem(null);
            while (rs.next()) {
                p = new Producto(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getFloat(4), rs.getString(5), rs.getFloat(6));
                cmbProductos.addItem(p);
            }
            cmbProductos.removeItemAt(0);
        }
        rs.close();
    }

    public static void cargarComboEmpleados(JComboBox<Empleado> cmbEmpleados) throws SQLException {
        Empleado e;
        cmbEmpleados.removeAllItems();
        String consulta = "select * from empleado";
        ResultSet rs;

        try ( Statement sentencia = Pool.getCurrentConexion().createStatement()) {
            rs = sentencia.executeQuery(consulta);
            cmbEmpleados.addItem(null);
            while (rs.next()) {
                e = new Empleado(rs.getString(1), rs.getString(2), rs.getFloat(3), rs.getFloat(4), rs.getInt(5));
                cmbEmpleados.addItem(e);
            }
            cmbEmpleados.removeItemAt(0);
        }
        rs.close();
    }

    public static void cargarcomboCliente(JComboBox<Cliente> cmbCliente) throws SQLException {
        Cliente c;
        cmbCliente.removeAllItems();
        String consulta = "select * from cliente";
        ResultSet rs;

        try ( Statement sentencia = Pool.getCurrentConexion().createStatement()) {
            rs = sentencia.executeQuery(consulta);
            cmbCliente.addItem(null);
            while (rs.next()) {
                c = new Cliente(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
                cmbCliente.addItem(c);
            }
            cmbCliente.removeItemAt(0);
        }
        rs.close();
    }

    public static void cargarTablaProductos(DefaultTableModel modeloProductos) throws SQLException {
        Producto p;
        String consulta = "select * from productos";
        ResultSet rs;
        modeloProductos.setRowCount(0);

        try ( Statement sentencia = Pool.getCurrentConexion().createStatement()) {
            rs = sentencia.executeQuery(consulta);
            while (rs.next()) {
                p = new Producto(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getFloat(4), rs.getString(5), rs.getFloat(6));

                Object[] datos = new Object[6];
                datos[0] = p.getIdProducto();
                datos[1] = p.getNomProducto();
                datos[2] = p.getStock();
                datos[3] = p.getPrecio();
                datos[4] = p.getCategoria();
                datos[5] = p.getIva();
                modeloProductos.addRow(datos);
            }
        }
        rs.close();
    }

    public static void cargarTablaClientes(DefaultTableModel modeloClientes) throws SQLException {
        Cliente c;
        String consulta = "select * from cliente";
        ResultSet rs;
        modeloClientes.setRowCount(0);

        try ( Statement sentencia = Pool.getCurrentConexion().createStatement()) {
            rs = sentencia.executeQuery(consulta);
            while (rs.next()) {
                c = new Cliente(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));

                Object[] datos = new Object[4];
                datos[0] = c.getIdCliente();
                datos[1] = c.getNombreCliente();
                datos[2] = c.getApellidoCliente();
                datos[3] = c.getDireccionCliente();
                modeloClientes.addRow(datos);
            }
        }
        rs.close();
    }

    public static void cargarTablaFacturaClientes(DefaultTableModel modeloFacturaClientes, String id) throws SQLException {
        Factura f;
        String consulta = "select * from factura where idcliente=?";
        ResultSet rs;
        modeloFacturaClientes.setRowCount(0);

        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(consulta)) {
            sentencia.setString(1, id);
            rs = sentencia.executeQuery();
            while (rs.next()) {
                if (rs.getInt(5) != 0) {
                    f = new Factura(rs.getString(1), rs.getString(2), rs.getString(3), rs.getTimestamp(4), true, rs.getFloat(6));
                } else {
                    f = new Factura(rs.getString(1), rs.getString(2), rs.getString(3), rs.getTimestamp(4), false, rs.getFloat(6));
                }

                Object[] datos = new Object[6];
                datos[0] = f.getNumFactura();
                datos[1] = f.getIdCliente();
                datos[2] = f.getIdEmpleado();
                datos[3] = f.getFecha();
                datos[4] = f.getIva();
                datos[5] = f.isCobrada();

                modeloFacturaClientes.addRow(datos);
            }
        }
        rs.close();
    }// </editor-fold> 

    public static Factura buscarFactura(String numFactura) throws SQLException {
        String query = "select * from factura where numfactura=?";
        Factura f = null;
        ResultSet rs;
        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(query)) {
            sentencia.setString(1, numFactura);

            rs = sentencia.executeQuery();

            while (rs.next()) {
                if (rs.getInt(5) != 0) {
                    f = new Factura(rs.getString(1), rs.getString(2), rs.getString(3), rs.getTimestamp(4), true, rs.getFloat(6));
                } else {
                    f = new Factura(rs.getString(1), rs.getString(2), rs.getString(3), rs.getTimestamp(4), false, rs.getFloat(6));
                }
            }
        }
        return f;
    }

    public static void Facturar(Factura f, Detalle[] d) throws SQLException {
        String queryfactura = "insert into factura values(?,?,?,?,?,?)";
        String querydetalle = "insert into detalle values(?,?,?,?,?)";
        int cobrada;
        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(queryfactura)) {
            sentencia.setString(1, f.getNumFactura());
            sentencia.setString(2, f.getIdCliente());
            sentencia.setString(3, f.getIdEmpleado());
            sentencia.setTimestamp(4, f.getFecha());

            if (f.isCobrada()) {
                cobrada = 1;
            } else {
                cobrada = 0;
            }

            sentencia.setInt(5, cobrada);
            sentencia.setFloat(6, f.getIva() * 100);

            sentencia.executeUpdate();
        }

        for (int i = 0; i < d.length; i++) {
            try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(querydetalle)) {
                sentencia.setString(1, d[i].getNumFactura());
                sentencia.setInt(2, i + 1);
                sentencia.setString(3, d[i].getIdProducto());
                sentencia.setInt(4, d[i].getCantidad());
                sentencia.setFloat(5, d[i].getPrecio());

                sentencia.executeUpdate();
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Cliente code">                          
    public static Cliente buscarCliente(String id) throws SQLException {
        String query = "select * from cliente where idcliente=?";
        Cliente c = null;
        ResultSet rs;
        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(query)) {

            sentencia.setString(1, id);
            rs = sentencia.executeQuery();

            while (rs.next()) {
                c = new Cliente(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
            }
        }
        rs.close();
        return c;
    }

    public static Cliente buscarClienteHistorico(String id) throws SQLException {
        String query = "select * from historicocliente where hidcliente=?";
        Cliente c = null;
        ResultSet rs;
        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(query)) {

            sentencia.setString(1, id);
            rs = sentencia.executeQuery();

            while (rs.next()) {
                c = new Cliente(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
            }
        }
        rs.close();
        return c;
    }

    public static void anhadirCliente(String id, String nombre, String apellido, String direccion) throws SQLException {
        String query = "insert into cliente values(?,?,?,?)";

        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(query)) {

            sentencia.setString(1, id);
            sentencia.setString(2, nombre);
            sentencia.setString(3, apellido);
            sentencia.setString(4, direccion);

            sentencia.executeUpdate();
        }
    }

    public static void modificarCliente(JTable tblClientes) throws SQLException {
        String query = "update cliente set nombrecli=?, apellidocli=?, dircli=? where idcliente=?";

        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(query)) {

            sentencia.setString(1, tblClientes.getValueAt(tblClientes.getSelectedRow(), 1).toString());
            sentencia.setString(2, tblClientes.getValueAt(tblClientes.getSelectedRow(), 2).toString());
            sentencia.setString(3, tblClientes.getValueAt(tblClientes.getSelectedRow(), 3).toString());
            sentencia.setString(4, tblClientes.getValueAt(tblClientes.getSelectedRow(), 0).toString());

            sentencia.executeUpdate();
        }
    }

    public static boolean comprobarClientePagado(String id) throws SQLException {
        String query = "select(case when cobrada='1' then true else false end) as 'prueba' from factura where idcliente=?";
        ResultSet rs;
        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(query)) {
            sentencia.setString(1, id);

            rs = sentencia.executeQuery();

            while (rs.next()) {
                if (rs.getLong(1) == 0) {
                    return false;
                }
            }
            return true;
        }
    }

    public static void borrarClienteDatos(String id) throws SQLException {
        String deleteDetalle = "delete detalle from detalle inner join factura on idcliente=? where factura.numfactura = detalle.numfactura";
        String deleteFactura = "delete from factura where idcliente=?";

        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(deleteDetalle)) {
            sentencia.setString(1, id);
            sentencia.executeUpdate();
        }

        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(deleteFactura)) {
            sentencia.setString(1, id);
            sentencia.executeUpdate();
        }
    }

    public static void borrarCliente(String id) throws SQLException {
        String deleteCliente = "delete from cliente where idcliente=?";

        borrarClienteDatos(id);

        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(deleteCliente)) {
            sentencia.setString(1, id);
            sentencia.executeUpdate();
        }
    }

    public static void anhadirClienteHistorico(Cliente c) throws SQLException {
        String query = "insert into historicocliente values(?,?,?,?)";

        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(query)) {
            sentencia.setString(1, c.getIdCliente());
            sentencia.setString(2, c.getNombreCliente());
            sentencia.setString(3, c.getApellidoCliente());
            sentencia.setString(4, c.getDireccionCliente());

            sentencia.executeUpdate();
        }
    }

    public static void anhadirClienteHistoricoFactura(Cliente c) throws SQLException {
        String query = "insert into historicofacturadoporcliente values(?,?,?,?)";
        String actualizar = "update historicofacturadoporcliente set importefacturado=?, observaciones=?";
        String buscarfactura = "select * from historicofacturadoporcliente where idcliente=?";
        String queryFactura = "select numfactura from factura where idcliente=?";
        String queryImporte = "select sum(precio*cantidad) as cantidad from detalle where numfactura=?";
        String factura = "";
        float importe = 0;
        float importefacturado = 0;
        String observaciones = null;
        ResultSet rsbuscar;
        ResultSet rsfactura;
        ResultSet rsimporte;

        try ( PreparedStatement sentenciabuscar = Pool.getCurrentConexion().prepareStatement(buscarfactura)) {
            sentenciabuscar.setString(1, c.getIdCliente());

            rsbuscar = sentenciabuscar.executeQuery();

            while (rsbuscar.next()) {
                importefacturado = rsbuscar.getFloat(3);
                observaciones = rsbuscar.getString(4);
            }
        }
        rsbuscar.close();

        try ( PreparedStatement sentenciafactura = Pool.getCurrentConexion().prepareStatement(queryFactura)) {
            sentenciafactura.setString(1, c.getIdCliente());

            rsfactura = sentenciafactura.executeQuery();

            while (rsfactura.next()) {
                factura += rsfactura.getString(1);

                if (rsfactura.next()) {
                    factura += ":" + rsfactura.getString(1);
                }
            }
        }
        rsfactura.close();

        String[] facturas = factura.split(":");
        for (int i = 0; i < facturas.length; i++) {
            if (i != facturas.length - 1) {
                queryImporte += " union " + queryImporte;
            }
        }

        queryImporte = "select sum(t.cantidad) from( " + queryImporte + ") as t";

        try ( PreparedStatement sentenciaimporte = Pool.getCurrentConexion().prepareStatement(queryImporte)) {

            for (int i = 0; i < facturas.length; i++) {
                sentenciaimporte.setString(i + 1, facturas[i]);
            }

            rsimporte = sentenciaimporte.executeQuery();

            while (rsimporte.next()) {
                importe = (float) rsimporte.getDouble(1);
            }
        }
        rsimporte.close();

        if (observaciones != null) {
            factura += ":" + observaciones;
            importe += importefacturado;
            try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(actualizar)) {
                sentencia.setFloat(1, importe);
                sentencia.setString(2, factura);
                
                sentencia.executeUpdate();
            }
            return;
        }

        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(query)) {
            sentencia.setString(1, c.getIdCliente());
            sentencia.setString(2, c.getNombreCliente());
            sentencia.setFloat(3, importe);
            sentencia.setString(4, factura);

            sentencia.executeUpdate();
        }
    }

    public static void recuperarClienteHistorico(String id) throws SQLException {
        String buscarcliente = "select * from historicocliente where hidcliente=?";
        String insertarcliente = "insert into cliente values(?,?,?,?)";
        ResultSet rs;
        Cliente c = null;
        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(buscarcliente)) {
            sentencia.setString(1, id);

            rs = sentencia.executeQuery();
            while (rs.next()) {
                c = new Cliente(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
            }
        }

        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(insertarcliente)) {
            sentencia.setString(1, c.getIdCliente());
            sentencia.setString(2, c.getNombreCliente());
            sentencia.setString(3, c.getApellidoCliente());
            sentencia.setString(4, c.getDireccionCliente());

            sentencia.executeUpdate();
        }
    }

    public static void cobrarFactura(String numFactura) throws SQLException {
        String actualizar = "update factura set cobrada = 1 where numfactura=?";

        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(actualizar)) {
            sentencia.setString(1, numFactura);

            sentencia.executeUpdate();
        }
    }// </editor-fold> 

    // <editor-fold defaultstate="collapsed" desc="Producto code">                          
    public static Producto buscarProducto(String id) throws SQLException {
        String query = "select * from productos where idproducto=?";
        Producto p = null;
        ResultSet rs;

        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(query)) {

            sentencia.setString(1, id);
            rs = sentencia.executeQuery();

            while (rs.next()) {
                p = new Producto(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getFloat(4), rs.getString(5), rs.getFloat(6));
            }
        }
        rs.close();
        return p;
    }

    public static void anhadirProducto(String id, String nombre, int stock, float precio, String categoria, float iva) throws SQLException {
        String query = "insert into productos values(?,?,?,?,?,?)";

        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(query)) {
            sentencia.setString(1, id);
            sentencia.setString(2, nombre);
            sentencia.setInt(3, stock);
            sentencia.setFloat(4, precio);
            sentencia.setString(5, categoria);
            sentencia.setFloat(6, iva);

            sentencia.executeUpdate();
        }
    }

    public static void modificarProducto(JTable tblProductos) throws SQLException {
        String query = "update productos set nomproducto=?, stock=?, precio=?, categoria=?, iva=? where idproducto=?";

        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(query)) {

            sentencia.setString(1, tblProductos.getValueAt(tblProductos.getSelectedRow(), 1).toString());
            sentencia.setInt(2, Integer.parseInt(tblProductos.getValueAt(tblProductos.getSelectedRow(), 2).toString()));
            sentencia.setFloat(3, Float.parseFloat(tblProductos.getValueAt(tblProductos.getSelectedRow(), 3).toString()));
            sentencia.setString(4, tblProductos.getValueAt(tblProductos.getSelectedRow(), 4).toString());
            sentencia.setFloat(5, Float.parseFloat(tblProductos.getValueAt(tblProductos.getSelectedRow(), 5).toString()));
            sentencia.setString(6, tblProductos.getValueAt(tblProductos.getSelectedRow(), 0).toString());

            sentencia.executeUpdate();
        }
    }

    public static Producto comprobarProductoenFactura(String id) throws SQLException {
        String query = "select * from productos inner join detalle on detalle.idproducto =? where productos.idproducto = detalle.idproducto";
        Producto p = null;
        ResultSet rs;

        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(query)) {
            sentencia.setString(1, id);

            rs = sentencia.executeQuery();
            while (rs.next()) {
                p = new Producto(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getFloat(4), rs.getString(5), rs.getFloat(6));
            }
        }
        rs.close();
        return p;
    }

    public static void borrarProducto(String id) throws SQLException {
        String deleteProducto = "delete from productos where idproducto = ?";

        try ( PreparedStatement sentencia = Pool.getCurrentConexion().prepareStatement(deleteProducto)) {
            sentencia.setString(1, id);

            sentencia.executeUpdate();
        }
    }// </editor-fold> 

}
