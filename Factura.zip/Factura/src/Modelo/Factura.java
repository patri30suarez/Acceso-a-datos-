/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Timestamp;

/**
 *
 * @author patt
 */
public class Factura {
    String numFactura;
    String idCliente;
    String idEmpleado;
    Timestamp fecha;
    boolean cobrada;
    float iva;

    public Factura() {
    }
    
    public Factura(String numFactura, String idCliente, String idEmpleado, Timestamp fecha, boolean cobrada, float iva) {
        this.numFactura = numFactura;
        this.idCliente = idCliente;
        this.idEmpleado = idEmpleado;
        this.fecha = fecha;
        this.cobrada = cobrada;
        this.iva = iva;
    }

    public String getNumFactura() {
        return numFactura;
    }

    public void setNumFactura(String numFactura) {
        this.numFactura = numFactura;
    }

    public String getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public String getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(String idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public Timestamp getFecha() {
        return fecha;
    }

    public void setFecha(Timestamp fecha) {
        this.fecha = fecha;
    }

    public boolean isCobrada() {
        return cobrada;
    }

    public void setCobrada(boolean cobrada) {
        this.cobrada = cobrada;
    }

    public float getIva() {
        return iva;
    }

    public void setIva(float iva) {
        this.iva = iva;
    }

    @Override
    public String toString() {
        return "Factura{" + "numFactura=" + numFactura + ", idCliente=" + idCliente + ", idEmpleado=" + idEmpleado + ", fecha=" + fecha + ", cobrada=" + cobrada + ", iva=" + iva + '}';
    }
}
