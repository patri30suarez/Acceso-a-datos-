/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author patt
 */
public class Detalle {

    String numFactura;
    int numDetalle;
    String idProducto;
    int cantidad;
    float precio;

    public Detalle() {
    }

    public Detalle(String numFactura,String idProducto, int cantidad, float precio) {
        this.numFactura = numFactura;
        this.idProducto = idProducto;
        this.cantidad = cantidad;
        this.precio = precio/cantidad;
    }

    public Detalle(String numFactura, int numDetalle, String idProducto, int cantidad, float precio) {
        this.numFactura = numFactura;
        this.numDetalle = numDetalle;
        this.idProducto = idProducto;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    public String getNumFactura() {
        return numFactura;
    }

    public void setNumFactura(String numFactura) {
        this.numFactura = numFactura;
    }

    public int getNumDetalle() {
        return numDetalle;
    }

    public void setNumDetalle(int numDetalle) {
        this.numDetalle = numDetalle;
    }

    public String getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Detalle{" + "numFactura=" + numFactura + ", numDetalle=" + numDetalle + ", idProducto=" + idProducto + ", cantidad=" + cantidad + ", precio=" + precio + '}';
    }

}
