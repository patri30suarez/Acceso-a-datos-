/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author patt
 */
public class Empleado {
    String idEmpleado;
    String nombreEmpleado;
    float salario;
    float incentivo;
    int operativas;

    public Empleado() {
    }

    public Empleado(String idEmpleado, String nombreEmpleado, float salario, float incentivo, int operativas) {
        this.idEmpleado = idEmpleado;
        this.nombreEmpleado = nombreEmpleado;
        this.salario = salario;
        this.incentivo = incentivo;
        this.operativas = operativas;
    }

    public String getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(String idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public float getIncentivo() {
        return incentivo;
    }

    public void setIncentivo(float incentivo) {
        this.incentivo = incentivo;
    }

    public int getOperativas() {
        return operativas;
    }

    public void setOperativas(int operativas) {
        this.operativas = operativas;
    }

    @Override
    public String toString() {
        return idEmpleado;
    }
    
}
