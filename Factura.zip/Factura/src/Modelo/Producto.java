/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author patt
 */
public class Producto {
    String idProducto;
    String nomProducto;
    int stock;
    float precio;
    String categoria;
    float iva;

    public Producto() {
    }

    public Producto(String idProducto, String nomProducto, int stock, float precio, String categoria, float iva) {
        this.idProducto = idProducto;
        this.nomProducto = nomProducto;
        this.stock = stock;
        this.precio = precio;
        this.categoria = categoria;
        this.iva = iva;
    }

    public String getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }

    public String getNomProducto() {
        return nomProducto;
    }

    public void setNomProducto(String nomProducto) {
        this.nomProducto = nomProducto;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public float getIva() {
        return iva;
    }

    public void setIva(float iva) {
        this.iva = iva;
    }

    @Override
    public String toString() {
        return nomProducto;
    }
    
}
